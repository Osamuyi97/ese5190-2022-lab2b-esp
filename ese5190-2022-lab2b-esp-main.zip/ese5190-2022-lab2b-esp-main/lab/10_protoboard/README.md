### TODO:

Add support for your custom circuit board to your sequencer, and give a demo.
