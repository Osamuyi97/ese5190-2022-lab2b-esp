### TODO:

Use the capabilities of your sequencer to implement the ADPS9960 protocol and control the sensor.
